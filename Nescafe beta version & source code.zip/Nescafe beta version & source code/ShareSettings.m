

%% Problem Definition
global ProblemSettings;
ProblemSettings.CostFunction=CostFunction;
ProblemSettings.nVar=nVar;
ProblemSettings.VarMin=VarMin;
ProblemSettings.VarMax=VarMax;

%% ICA Settings
global ICASettings;
ICASettings.nPop=nPop;
ICASettings.nImp=nImp;
ICASettings.nCol=nPop-nImp;
ICASettings.MaxDecades=MaxDecades;
ICASettings.beta=beta;
ICASettings.pRevolution=pRevolution;
ICASettings.zeta=zeta;
