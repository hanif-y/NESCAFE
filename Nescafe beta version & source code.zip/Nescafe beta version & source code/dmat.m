function sil=dmat(class)
global dmat1;
global params;
for i=1:size(params,1)
    w=class==class(i);
    if sum(w)>1
    s=dmat1(w,i);
    ss=sum(s);
    s1=ss./(sum(w)-1);
% s1=mean(s);
    else
        s1=0;
    end
    k=0;
   for j=1:max(class)
     if j~=class(i)
         k=k+1;
         w1=class==j;
         s2=dmat1(w1,i);
         s3(k)=mean(s2);
     end
   end
   a(i)=s1;
   b(i)=min(s3);
   sil(i)=(b(i)-a(i))./max([b(i),a(i)]);
end