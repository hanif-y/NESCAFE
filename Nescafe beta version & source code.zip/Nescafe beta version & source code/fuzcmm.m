function [J,u,IC,class,dc,Xie]=fuzcmm(X,c,m,IC,sig,itr,flag)
% global pd;
global oft
for t=1:itr

if flag==2
dc1=(dist(X,IC')').^2;
n1=1- vecnorm(IC,2,2).^2;
n2=1- vecnorm(X,2,2).^2;
f1=n1.*n2';
dc=real(acosh(1+2*(dc1./f1)));
% ss=dc<0;
% dc(ss)=0;
elseif flag==1
% dc=(dist(X,IC')');
dc = (pdist2(X,IC,'euclidean'))';
% ss=dc<=0.0001;
% dc(ss)=0.001;
elseif flag==3
dc = (pdist2(X,IC,'correlation'))';
% ss=dc<=0.00001;
% dc(ss)=0.0001;

% dc1 = (pdist2(X,IC,'correlation'))';
% 
% ddd=-1*dc1+2;
% dc=(dc1./ddd).^2;
end
for i=1:size(dc,1)
    for j=1:size(dc,2)
        dr=(dc(i,j)./dc(:,j)).^(2/(m-1));
%         dn=(dc(i,j)./sig).^(2/(m-1));
      dn=0;
        u(i,j)=  1./(sum(dr)+dn);
    end
%     IC(i,:)=sum((u(i,:).^m)'.*X)./(sum(u(i,:)));
end
end
% r=1-dc;
% z=(r.*sqrt(size(X,2)-2))./(sqrt(1-r.^2));
% u=0.5*ones(c,size(X,1));

% y = cdf(pd,z);
% y1=sort(y);
% u=y;
if oft==3||oft==4
JJ=(u.^m).*(dc.^2);
J=sum(sum(JJ,2));
% J=Jj+sum(sig^2.*(1-sum(u)).^m);
else
J=0;
end
% 
if oft==2
    J1=(u.^2).*(dc.^2);
Jj=sum(sum(J1,2));
if size(IC,1)>=2
    
rrk = (pdist(IC,'correlation'))';
ss=rrk<=0.00001;
rrk(ss)=0.0001;
Xie=Jj/(size(X,1)*(min(rrk)));
else
Xie=Jj/(size(X,1)*0.00001);   
end
else
Xie=0;    
end
% PC=1;


% PC=1/(size(X,1))*sum(sum(u.*(u)));
a1=u==max(u);
[a, ~]=find(a1==1);
class=a';
% s=1;
% su=sort(dc);
% ssil=su(2,:)-su(1,:);
% s=mean(ssil./su(2,:));
% s=mean(y1(end,:)-y1(end-1,:));
% s=abs(s);
% % BIC = bic(X,class,IC);
% n=size(X,1);
% RSS=0;
% for i=1:size(X,1)
% %     RSS=RSS+sqrt((y(i,1)-C(idx(i),1))^2+(y(i,2)-C(idx(i),2))^2);
%     RSS=RSS+sum(sqrt((X(i,:)-IC(class(i),:)).^2)); 
% end
% % BIC(temp)=n*log(RSS/n)+k*log(n);
% BIC=n*log(RSS/n)+(c)*log(n);