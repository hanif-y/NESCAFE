function [class,U,centres,error,dc]=dcff(x)
% global params;
% data=params;
% cc=x(1,1);
% m=x(1,2);
% ic=x(4:end);
% % r=size(data,2);
% icc=data(ic,:);
% xx=x(1,3);
% % [class,U,centres,error] = dcFuzzy(data,cc,m,icc,100);
% % [~,error,U,centres,class]=fuzcm2(data,cc,m,icc,xx,50,1);
% global pd;
global params;
data=params;
global nn;
global mk
global cdist
cc=x(1,1);
m=x(1,2);
xx=x(1,3);
xx1=x(1,4);
t=1:size(data,2);
if mk==1
for i=1:cc
icc(i,:)=mkfrbf1(t,x((5:4+nn/2)+(i-1)*nn),x((5+nn/2:4+nn)+(i-1)*nn));
end
elseif mk==0
for i=1:cc
icc(i,:)=x((5:4+nn)+(i-1)*nn);
end
end

% [BIC,error,~,U,centres,class,~,dc]=fuzcm(data,cc,m,icc,xx,1,2);
[error,U,centres,class,dc]=fuzcmm(data,cc,m,icc,xx,1,cdist);
% asg=real(u{1,2});
% % U=asg./(cc);
% U=asg;
% a1=U==max(U);
% [a, ~]=find(a1==1);
% class=a';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% MATLAB Code for                                               %
%                                                               %
%  ICAFCM CLuSTERING                                            %
%                                                               %
%                                                               %
%    Programmed By: H.yaghoobi                                  %
%                                                               %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%