%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  Portion of MATLAB Code for                                   %
%                                                               %
%  Imperialistic Competitive Algorithm (ICA)                    %
%  Version 1.9 - May 2010                                       %
%                                                               %
%    Programmed By: S. Mostapha Kalami Heris                    %
%                   Member of MATLABSITE.com Programmers Group  %
%                                                               %
%         Site URL: http://www.matlabsite.com                   %
%                                                               %
%  Support e-Mails: info@matlabsite.com                         %
%                                                               %
%   Author e-Mails: sm.kalami@gmail.com                         %
%                   kalami@ee.kntu.ac.ir                        %
%                                                               %
%  Author Homepage: http://www.kalami.ir                        %
%                                                               %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%clc;
%clear;
%close all;
global Sol;
global cc;
global nn;
global params
global iteration
global Nimp
global Nc
global mk
global citr
global str;
global mincc
global ofd
% mincc=4;
% cc=8;
if mk==0
nn=size(params,2);
elseif mk==1
nn=2*citr;
end
global pd;
pd = makedist('Normal');
global dmat1;
global cdist
dmat1 = distfun(params,params,ofd);
%% Problem Definition

CostFunction=@(x)My_Fun(x);

% nVar=nn+(cc-1)*nn+4;       % Number of Unknown Variables
nVar=cc*nn+4;
VarMin=0;     % Lower Bound of Unknown Variables
VarMax=50;    % Upper Bound of Unknown Variables

%% ICA Settings

nPop=Nc;     % Number of Countries
nImp=Nimp;      % Number of Imperials
nCol=nPop-nImp;

MaxDecades=iteration;

beta=2;

pRevolution=0.4;

zeta=0.02;

%% Initialization

ShareSettings;

imp=InitializeImperials();

BestSol.Position=[];
BestSol.Cost=[];

BestCost=zeros(ICASettings.MaxDecades,1);
MeanCost=zeros(ICASettings.MaxDecades,1);
h1 = waitbar(0,sprintf('Please wait.....     Cost=%d',BestCost(1)));
% set(findall(h1),'Units', 'normalized');
% set(h1,'Position', [0.25 0.4 0.5 0.15]);
% wax = findobj(h1, 'type','axes');
% tax = get(wax,'title');
% set(tax,'fontsize',15)
%% ICA
for Decade=1:MaxDecades
    
    imp=AssimilateColonies(imp);
    
    imp=RevolveColonies(imp);
    
    imp=ExchangeWithBestColony(imp);
    
    imp=CalculateTotalCosts(imp);
    
    imp=ImperialisticCompetition(imp);

    ImpCost=[imp.Cost];
    [BestImpCost BestImpIndex]=min(ImpCost);
    BestImp=imp(BestImpIndex);
    
    BestSol.Position=BestImp.Position;
    BestSol.Cost=BestImp.Cost;
    
    BestCost(Decade)=BestImpCost;
    MeanCost(Decade)=mean(ImpCost);
    
%     disp(['Decade ' num2str(Decade) ...
%           ': Best Cost = ' num2str(BestCost(Decade)) ...
%           ', Mean Cost = ' num2str(MeanCost(Decade)) ...
%           ', nImp = ' num2str(numel(imp))]);
 waitbar(Decade/MaxDecades,h1,sprintf('please wait.....Cost=%d',BestCost(Decade)));   
 if BestImpCost<=str
     break
 end
end
close(h1);
figure;
semilogy(BestCost,'b','LineWidth',2);
hold on;
semilogy(MeanCost,'r:','LineWidth',2);
legend('Best Cost','Mean Cost');
xlabel('Decade');
Sol=BestSol.Position;