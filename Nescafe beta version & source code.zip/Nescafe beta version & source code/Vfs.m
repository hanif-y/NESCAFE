% The validity index -> VFs(X,c,V,U,m) = sum<i=1~c>{ sum<k=1~n>{ (Uik ^ m) *
%                       (||Xk - Vi||^2 - ||Vi - V_mean||^2) } }
%                       where V_mean = (1/n) * sum<i=1~c>{ Vi }
% -------------------------------------------------------------------------

function VFs = Vfs(X,c,V,U,m)

sum_fin = 0;
n = size(U,2);
V_mean = sum(V) / n;

for i=1:c
    for k=1:n
        tmp_1 = U(i,k)^m;
        tmp_2 = (norm(X(k,:) - V(i,:)))^2;
        tmp_3 = (norm(V(i,:) - V_mean))^2;
        sum_fin = sum_fin + tmp_1 * (tmp_2 - tmp_3);
    end
end

VFs = sum_fin;