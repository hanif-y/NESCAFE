
function imp=RevolveColonies(imp)

    global ProblemSettings;
    global ICASettings;
    global cc
    CostFunction=ProblemSettings.CostFunction;
    nVar=ProblemSettings.nVar;
    VarMin=ProblemSettings.VarMin;
    VarMax=ProblemSettings.VarMax;
    
    pRevolution=ICASettings.pRevolution;
    
    for i=1:numel(imp)
        for j=1:imp(i).nCol
            if rand<pRevolution
                k=randi([5 nVar]);
                
                imp(i).Colonies(j).Position(k)=unifrnd(VarMin,VarMax);
                
                imp(i).Colonies(j).Cost=CostFunction(imp(i).Colonies(j).Position);
            end
        end
    end
    for i=1:numel(imp)
        for j=1:imp(i).nCol
            if rand<pRevolution
                
                x1=randi([-1 1]);
                
                if (imp(i).Colonies(j).Position(1,1)>3 && x1<0)||(imp(i).Colonies(j).Position(1,1)<cc && x1>0)
                imp(i).Colonies(j).Position(1,1)=imp(i).Colonies(j).Position(1,1)+x1;
                end
                imp(i).Colonies(j).Cost=CostFunction(imp(i).Colonies(j).Position);
            end
        end 
    end

end