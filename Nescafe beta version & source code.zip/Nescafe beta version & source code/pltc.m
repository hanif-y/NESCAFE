j=3;
for i=[1:8]
%     rf=S{1,1}(r2(j,1),1)-S{1,i}(r2(j,i),1);
    rf1=S{1,i}(r2(j,i),:);
    plot(rf1,'LineWidth',1.5)
    hold on
end