

function imp=AssimilateColonies(imp)

    global ProblemSettings;
    global ICASettings;
    global nn;
    CostFunction=ProblemSettings.CostFunction;
    VarMin=ProblemSettings.VarMin;
    VarMax=ProblemSettings.VarMax;
    
    beta=ICASettings.beta;
    
    for i=1:numel(imp)
        for j=1:imp(i).nCol
            d=imp(i).Position(1,2)-imp(i).Colonies(j).Position(1,2);
            x=beta*rand.*d;
            imp(i).Colonies(j).Position(1,2)=imp(i).Colonies(j).Position(1,2)+x;
            imp(i).Colonies(j).Position(1,2)=min(max(imp(i).Colonies(j).Position(1,2),1),2);
            d1=imp(i).Position(1,3)-imp(i).Colonies(j).Position(1,3);
            x1=beta*rand.*d1;
            imp(i).Colonies(j).Position(1,3)=imp(i).Colonies(j).Position(1,3)+x1;
            imp(i).Colonies(j).Position(1,3)=min(max(imp(i).Colonies(j).Position(1,3),1),10);
            d3=imp(i).Position(1,4)-imp(i).Colonies(j).Position(1,4);
            x1=beta*rand.*d3;
            imp(i).Colonies(j).Position(1,4)=imp(i).Colonies(j).Position(1,4)+x1;
            imp(i).Colonies(j).Position(1,4)=min(max(imp(i).Colonies(j).Position(1,4),1),10);
            k=imp(i).Position(1,1);
            for ii=1:k
            d2=imp(i).Position(1,(5:4+nn/2)+(ii-1)*nn)-imp(i).Colonies(j).Position(1,(5:4+nn/2)+(ii-1)*nn);
            
            x=beta*rand(size(d2)).*d2;
%             imp(i).Colonies(j).Position(1,5:k*nn+4)=imp(i).Colonies(j).Position(1,5:k*nn+4)+x;
            imp(i).Colonies(j).Position(1,(5:4+nn/2)+(ii-1)*nn)=imp(i).Colonies(j).Position(1,(5:4+nn/2)+(ii-1)*nn)+x;
%             imp(i).Colonies(j).Position(1,5:k*nn+4)=min(max(imp(i).Colonies(j).Position(1,5:k*nn+4),VarMin),VarMax);
            imp(i).Colonies(j).Position(1,(5:4+nn/2)+(ii-1)*nn)=min(max(imp(i).Colonies(j).Position(1,(5:4+nn/2)+(ii-1)*nn),VarMin),VarMax);
            
            d2=imp(i).Position(1,(5+nn/2:4+nn)+(ii-1)*nn)-imp(i).Colonies(j).Position(1,(5+nn/2:4+nn)+(ii-1)*nn);
            x=beta*rand(size(d2)).*d2;
            imp(i).Colonies(j).Position(1,(5+nn/2:4+nn)+(ii-1)*nn)=imp(i).Colonies(j).Position(1,(5+nn/2:4+nn)+(ii-1)*nn)+x;
            imp(i).Colonies(j).Position(1,(5+nn/2:4+nn)+(ii-1)*nn)=min(max(imp(i).Colonies(j).Position(1,(5+nn/2:4+nn)+(ii-1)*nn),VarMin),VarMax);
            end
            imp(i).Colonies(j).Cost=CostFunction(imp(i).Colonies(j).Position);  
        end
    end
    
end