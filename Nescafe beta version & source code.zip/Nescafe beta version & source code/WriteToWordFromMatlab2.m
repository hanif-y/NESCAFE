global solr;
global V;
% global U;
global EV;
global V2;
global EV1;
global EV11;
% global U1;
[file,path] = uiputfile;
	WordFileName=file;
	CurDir=path;
	FileSpec = fullfile(CurDir,WordFileName);
	[ActXWord,WordHandle]=StartWord(FileSpec);
    Style='Heading 1'; %NOTE! if you are NOT using an English version of MSWord you get
    % an error here. For Swedish installations use 'Rubrik 1'. 
    TextString='NESCAFE Results';
    WordText(ActXWord,TextString,Style,[0,1]);%two enters after text
    
    Style='Normal';
    TextString='This reports are generated automatically by EClust';    
    WordText(ActXWord,TextString,Style,[0,0]);%enter after text

    style='Heading 1';
    text='1. Primery Results';
    WordText(ActXWord,text,style,[1,2]);%enter before and after text 
    
    Style='Heading 2';
    TextString='Optimized parameters';
    WordText(ActXWord,TextString,Style,[0,0]);%enter after text
    
    [NoRows,NoCols]=size(solr);          
    %create table with data from DataCell
   
    WordCreateTable(ActXWord,NoRows,NoCols,solr,2);%enter before table
    
%     Style='Heading 2';
%     TextString='Non-merged clusters';
%     WordText(ActXWord,TextString,Style,[2,0]);%enter after text
%   
%     [NoRows,NoCols]=size(V);          
%     %create table with data from DataCell
%     WordCreateTable(ActXWord,NoRows,NoCols,V,1);%enter before table
    
%     Style='Heading 2';
%     TextString='Membership matrix';
%     WordText(ActXWord,TextString,Style,[1,0]);%enter after text
%   
%     [NoRows,NoCols]=size(U);          
%     %create table with data from DataCell
%     WordCreateTable(ActXWord,NoRows,NoCols,U,0);%enter before table
    
    Style='Heading 2';
    TextString='Clusternig evaluation';
    WordText(ActXWord,TextString,Style,[1,0]);%enter after text
  
    [NoRows,NoCols]=size(EV);          
    %create table with data from DataCell
    WordCreateTable(ActXWord,NoRows,NoCols,EV,0);%enter before table
    
    
%     ActXWord.Selection.InsertBreak;
%     style='Heading 1';
%     text='2. Final Results';
%     WordText(ActXWord,text,style,[0,2]);%enter before and after text
%     
%     Style='Heading 2';
%     TextString='Final clusters';
%     WordText(ActXWord,TextString,Style,[0,0]);%enter after text
%     [NoRows,NoCols]=size(V2);          
%     %create table with data from DataCell
%     WordCreateTable(ActXWord,NoRows,NoCols,V2,1);%enter before table
    
    Style='Heading 2';
    TextString='Evaluation of merged clusters by changing the merge parameter.';
    WordText(ActXWord,TextString,Style,[2,0]);%enter after text
    [NoRows,NoCols]=size(EV1);          
    %create table with data from DataCell
    WordCreateTable(ActXWord,NoRows,NoCols,EV1,1);%enter before table
   
    Style='Heading 2';
    TextString='Best clusters evaluation';
    WordText(ActXWord,TextString,Style,[1,0]);%enter after text
    [NoRows,NoCols]=size(EV11);          
    %create table with data from DataCell
    WordCreateTable(ActXWord,NoRows,NoCols,EV11,0);%enter before table
    
%     Style='Heading 2';
%     TextString='Final membership matrix';
%     WordText(ActXWord,TextString,Style,[1,0]);%enter after text
%     [NoRows,NoCols]=size(U1);          
%     %create table with data from DataCell
%     WordCreateTable(ActXWord,NoRows,NoCols,U1,0);%enter before table
    

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%        
%add pagenumbers (0=not on first page)
    WordPageNumbers(ActXWord,'wdAlignPageNumberRight');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%        
    
CloseWord(ActXWord,WordHandle,FileSpec);    
    close all;















































































































