function dc=distfun(X,IC,flag)

if flag==2
dc1=(dist(X,IC')').^2;
n1=1- vecnorm(IC,2,2).^2;
n2=1- vecnorm(X,2,2).^2;
f1=n1.*n2';
dc=real(acosh(1+2*(dc1./f1)));
% ss=dc<=0;
% dc(ss)=0.0001;
elseif flag==1
% dc=(dist(X,IC')');
dc = (pdist2(X,IC,'euclidean'))';
% ss=dc<=0.0001;
% dc(ss)=0.001;
elseif flag==3
dc = (pdist2(X,IC,'correlation'))';
% ss=dc<=0.00001;
% dc(ss)=0.0001;
% dc1 = (pdist2(X,IC,'correlation'))';
% 
% ddd=-1*dc1+2;
% dc=(dc1./ddd).^2;
end