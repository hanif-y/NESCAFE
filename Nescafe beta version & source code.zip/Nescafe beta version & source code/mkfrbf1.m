function y=mkfrbf1(x,k,c)
y=0;
c=abs(c);
% n=round(TSim/h);
% if To==0
%     m=-1;
% else
% m=round(To/h);
% end
% x=-m*h:h:TSim;
for i=1:size(c,2)
    y=y+k(:,i).*exp(-(abs(x-c(:,i))).^2);
end
% y=(y-min(y))./(max(y)-min(y));