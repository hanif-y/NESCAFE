global params
global Dy;
global mergo;
global Sol;
global class;
global class2;
global Ra;
global U;
global U1;
global A1;
global Lia;
global Dy1;
global Ev11;
global EV11;
global V2;
global cri1;
global cri2;
global cri3;
global cri4;
global L;
global eva1;
U1=[];
Ev11=[];
mn1=0;
aa=mergo;
for mn=aa
    merg1=mn;
    mn1=mn1+1;
class2=class;
Data=params;
Gname=Ra;
V3={};
V2={};
C1={};
Dy1=[];

CS=corrcoef(Dy');
tr=CS>=merg1;

Q=1:Sol(1,1);
R={};
for kk=1:size(tr,2)
    R{1,kk}=(Q(1,tr(:,kk)))';
end

i=1;
j=2;
n=0;
while i~=(size(R,2)-1) 
    for j=(i+1):size(R,2)    
 m=intersect(R{1,i},R{1,j});
 if ~isnan(m)
     sd=min(i,j);
     sq=max(i,j);
     R{1,sd}=union(R{1,i},R{1,j});
     R{1,sq}=[];
     i=1;
     n=n+1;
%  break;    
 end
 j=j+1;
    end
    if n~=0
        i=1;
        n=0;
    elseif n==0
      i=i+1;
    end
end
g=0;
for k=1:size(R,2)
    if ~isnan(R{1,k})
        g=g+1;
s=class2==R{1,k};
s=sum(s);
s=s==1;

class2(1,s)=min(R{1,k});
U1(g,:)=sum(U(R{1,k},:),1);
   end
end
Lia = ismember(Q,class2);
i=0;

for k=find(Lia==1)
    i=i+1;
  A1{i}=Data(class2==k,:);
  B=Gname(class2==k,:);
for k=1:size(B,1)
    V3{k,i}=B{k,1};
end  
if size(A1{1,i},1)>1 
    C1{i}=mean(A1{1,i}); 
else
    C1{i}=(A1{1,i});
end
end  

for i=1:size(C1,2)
    Dy1(i,:)=C1{1,i};
end
 
Ev11(mn1,1) = Vpc(U1);
Ev11(mn1,2) = Vpe(size(C1,2),U1);
Ev11(mn1,3) = Vfs(params,size(C1,2),Dy1,U1,Sol(1,2));
Ev11(mn1,4) = Vxie(params,size(C1,2),Dy1,U1,Sol(1,2));
Ev11(mn1,5) = Vrlr(params,size(C1,2),Dy1,U1,Dis([],size(C1,2),Dy1));
if cri1==1
eva1 = evalclusters(params,class2','Silhouette','Distance','correlation');
Ev11(mn1,6)=mean(eva1.ClusterSilhouettes{1,1});
else 
Ev11(mn1,6)=nan;
end
if cri2==1
eva2 = evalclusters(params,class2','DaviesBouldin'); 
Ev11(mn1,7)=eva2.CriterionValues;
else
Ev11(mn1,7)=nan;
end
if cri3==1
eva3 = evalclusters(params,class2','CalinskiHarabasz'); 
Ev11(mn1,8)=eva3.CriterionValues;
else
Ev11(mn1,8)=nan;
end

if cri4==1
[~,Ev11(mn1,9),~,~]=RandIndex(L',class2');
else
Ev11(mn1,9)=nan;
end
end


for ii=1:size(C1,2)
    V2(1,ii)={sprintf('Cluster %d',floor(ii))};
end
V2(2:(size(V3,1)+1),:)=V3;
for i=1:size(V2,1)
    for j=1:size(V2,2)
        if isempty(V2{i,j})
            V2{i,j}='';
        end
    end
end
EV11={};
EV11(1,2)={'Partition Coefficient'};
EV11(1,3)={'Partition Entropy'};
EV11(1,4)={'Fakuyama & Sugeno'};
EV11(1,5)={'Xie & Beni Index'};
EV11(1,6)={'Rezaee et al'};
EV11(1,7)={'Silhouette'};
EV11(1,8)={'DaviesBouldin'};
EV11(1,9)={'CalinskiHarabasz'};
EV11(1,10)={'Rand Index'};
for ii=1:size(Ev11,2)
    for jj=1:size(Ev11,1)
EV11{jj+1,ii+1}=num2str(Ev11(jj,ii));
    end
end
EV11(1,1)={'N-Clusters'};
for jj=1:size(Ev11,1)
EV11{jj+1,1}=num2str(sum(Lia));
end
for i=1:size(EV11,1)
    for j=1:size(EV11,2)
        if isempty(EV11{i,j})
            EV11{i,j}='';
        end
    end
end