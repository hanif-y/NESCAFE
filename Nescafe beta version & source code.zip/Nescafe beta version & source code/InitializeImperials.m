

function imp=InitializeImperials()

    global ProblemSettings;
    global ICASettings;
    global cc;
    global mincc
    CostFunction=ProblemSettings.CostFunction;
    nVar=ProblemSettings.nVar;
    VarMin=ProblemSettings.VarMin;
    VarMax=ProblemSettings.VarMax;
    
    nPop=ICASettings.nPop;
    nImp=ICASettings.nImp;
    nCol=ICASettings.nCol;
    
    EmptyColony.Position=[];
    EmptyColony.Cost=[];
    
    Colonies=repmat(EmptyColony,nPop,1);
    for k=1:nPop
        m=unifrnd(1,2);
        xx=unifrnd(1.01,2);
        xx1=unifrnd(1.01,50);
        c=randi([mincc cc]);
        Colonies(k).Position=([c m xx xx1 unifrnd(VarMin,VarMax,[1 nVar-4])]);
        Colonies(k).Cost=CostFunction(Colonies(k).Position);
    end

    [~, CostsSortOrder]=sort([Colonies.Cost]);
    Colonies=Colonies(CostsSortOrder);
    
    EmptyImperial.Position=[];
    EmptyImperial.Cost=[];
    EmptyImperial.TotalCost=[];
    EmptyImperial.nCol=[];
    EmptyImperial.Colonies=[];
    
    imp=repmat(EmptyImperial,nImp,1);
    for i=1:nImp
        imp(i).Position=Colonies(i).Position;
        imp(i).Cost=Colonies(i).Cost;
    end
    
    Colonies=Colonies(nImp+1:end);
    if isempty(Colonies)
        return;
    end
    
    ImpCosts=[imp.Cost];
    MaxImpCost=max(ImpCosts);
    ImpFitness=1.2*MaxImpCost-ImpCosts;
    p=ImpFitness/sum(ImpFitness);
    nc=abs(round(p*nCol));
    snc=sum(nc);
    
    if snc>nCol
        i=1;
        while snc>nCol
            nc(i)=max(nc(i)-1,1);
            i=i+1;
            if i>nImp
                i=1;
            end
            snc=sum(nc);
        end
    elseif snc<nCol
        i=nImp;
        while snc<nCol
            nc(i)=nc(i)+1;
            i=i-1;
            if i<1
                i=nImp;
            end
            snc=sum(nc);
        end
    end
    
    Colonies=Colonies(randperm(nCol));
    
    for i=1:nImp
        imp(i).nCol=nc(i);
        imp(i).Colonies=Colonies(1:nc(i));
        Colonies=Colonies(nc(i)+1:end);
    end
    
end