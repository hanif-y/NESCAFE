% global params1
% global Ra;
% global Sol;
global cri1;
global Lia;
global A1;
global V2;
global eva1;
% global Dy1;
V2={};
ppostprocessing2;

i=0;
figure(5);
for k=find(Lia==1)
    i=i+1;   
    subplot(3,floor(size(find(Lia==1),2)/3)+1,i)
    plot(A1{1,i}','LineWidth',1.5);
    title(sprintf('Cluster = %d',floor(i)));
    grid on;
    ax = gca;
    ax.FontSize = 12;
    ax.LineWidth=1.5;
end
if cri1==1
% eva = evalclusters(params,class2','Silhouette');
figure(6);

bar(eva1.ClusterSilhouettes{1,1})
title('Silhouette Index of Clusters');
Sil=mean(eva1.ClusterSilhouettes{1,1});
ax = gca;
ax.FontSize = 12;
ax.LineWidth=1.5;
end
