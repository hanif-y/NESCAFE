function y=My_Fun(x)
global params;
global nn;
global mk
data=params;
global cdist
global oft
% global dmat1;
cc=x(1,1);
m=x(1,2);
xx=x(1,3);
xx1=x(1,4);
t=1:size(data,2);
if mk==1
for i=1:cc
icc(i,:)=mkfrbf1(t,x((5:4+nn/2)+(i-1)*nn),x((5+nn/2:4+nn)+(i-1)*nn));
end
elseif mk==0
for i=1:cc
icc(i,:)=x((5:4+nn)+(i-1)*nn);
end
end
% [BIC,error,Xie,~,~,class,PC,~,s]=fuzcm(data,cc,m,icc,xx,1,2);
[error,u,IC,class,dc,Xie]=fuzcmm(data,cc,m,icc,xx,1,cdist);

% r1=class';
% if size(r1,1)==size(data,1)
% g=silhouette(params,r1,'correlation');
% else
% g=0;
% end
if oft==1
g=dmat(class);
y=-1*mean(g);
elseif oft==4
% y=(1/xx1)*(error)+xx1*cc/(2+round(log10(size(data,1))));
y=(1/xx)*(error)+xx*cc;
% y=-1*PC;

% y=(mean(error)*cc^(2*mean(error)));
% y = 1/(xx1)*cc+xx1*Xie;
elseif oft==2
y=Xie;
% y=-10*s;
% y=error-xx1*s;
% y=BIC;
elseif oft==3
y=error;
end
if isnan(y)
    y=100;
end
    