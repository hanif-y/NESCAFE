%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% MATLAB Code for                                               %
%                                                               %
%  ICAFCM CLuSTERING                                            %
%                                                               %
%                                                               %
%    Programmed By: H.yaghoobi                                  %
%                                                               %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function i=IcSelection(p)

%     c=cumsum(p);
%     r=rand();
    r=rand(1,size(p,2));
    D=p-r;
%     i=find(r<=c,1,'first');
i=find(D==max(D));
end