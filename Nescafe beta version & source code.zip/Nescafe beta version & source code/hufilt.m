function [H,params,Ra,jk]=hufilt(params,Ra,tr)
h1 = waitbar(0,sprintf('Please wait.....'));
for i=1:size(params,1)
H(i,1) = genhurst(params(i,:),1,size(params,2)/2-1);
% H(i,1) = hurst(params(i,:));
% H(i,1) =estimate_hurst_exponent(params(i,:));
waitbar(i/size(params,1),h1,sprintf('please wait.....'));
end
jk=H>=tr;
dina=params(jk,:);
params=dina;

Ra=Ra(jk,:);
close(h1);