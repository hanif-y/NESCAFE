global params
global Ra;
global U;
global V;
global Sol
global Dy;
global Ev1;
global EV;
global class;
global solr;
global cri1;
global cri2;
global cri3;
global cri4;
global L;
global pd;
global fcc;
pd = makedist('Normal');
% global cc;
solr={};
solr(1,1)={'Cluster Number'};
solr(1,2)={'m'};
solr(1,3)={'Alpha'};
% for ii=4:size(Sol,2)
% solr(1,ii)={sprintf('Center %d',floor(ii-3))};
% end
for ii=1:3
solr{2,ii}=num2str(Sol(1,ii));
end
[class,U,centres,error,dc]=dcff(Sol);
Data=params;
Gname=Ra;
V1={};
V={};
Dy=[];
Ev1=[];
C={};
A={};
B={};
i=0;
figure(2)
for kk=intersect(class,class)
% if ~isempty(Data(class==kk,:))
    i=i+1;
A{i}=Data(class==kk,:);
B=Gname(class==kk,:);
for k=1:size(B,1)
    V1{k,i}=B{k,1};
end  
if size(A{1,i},1)>1
    if fcc==1
  C{i}=mean(A{1,i});
    elseif fcc==0
  C{i}=centres(i,:);
    end
else
    if fcc==1
  C{i}=(A{1,i});
   elseif fcc==0
  C{i}=centres(i,:);
    end
end
    subplot(3,floor(Sol(1,1)/3)+1,i)
    plot(A{1,i}','LineWidth',1.5);
%     subplot(3,floor(Sol(1,1)/3)+1,i)
%     clustergram(A{1,i},'Standardize','row','Cluster',1);

    title(sprintf('Cluster %d',floor(i)));
    grid on;
    ax = gca;
    ax.FontSize = 12;
%   ax.LineWidth=1.5;
end
i=0;

for kk=intersect(class,class)
i=i+1;
clustergram(A{1,i},'RowLabels',Gname(class==kk,:),'Standardize','row','Cluster',1);
end  
% end
figure(3);
for i=1:i
  Dy(i,:)=C{1,i};
%     Dy(i,:)=centres(i,:);
    subplot(3,floor(Sol(1,1)/3)+1,i)
    plot(C{1,i}','LineWidth',1.5);
% bar(C{1,i}','LineWidth',1.5);
    title(sprintf('Center %d',floor(i)));
    grid on;
    ax = gca;
    ax.FontSize = 12;
    ax.LineWidth=1.5;
end
Ev1(1,1) = Vpc(U);
Ev1(1,2) = Vpe(size(C,2),U);
Ev1(1,3) = Vfs(params,size(C,2),Dy,U,Sol(1,2));
Ev1(1,4) = Vxie(params,size(C,2),Dy,U,Sol(1,2));
Ev1(1,5) = Vrlr(params,size(C,2),Dy,U,Dis([],size(C,2),Dy));
if cri1==1
% eva1 = evalclusters(params,class','Silhouette');
Ev1(1,6)=mean(dmat(class))  ;
else 
Ev1(1,6)=nan;
end
if cri2==1
eva2 = evalclusters(params,class','DaviesBouldin'); 
Ev1(1,7)=eva2.CriterionValues;
else
Ev1(1,7)=nan;
end
if cri3==1
eva3 = evalclusters(params,class','CalinskiHarabasz'); 
Ev1(1,8)=eva3.CriterionValues;
else
Ev1(1,8)=nan;
end
if cri4==1 
[~,Ev1(1,9),~,~]=RandIndex(L',class');
else
Ev1(1,9)=nan;
end
EV={};
EV(1,1)={'Partition Coefficient'};
EV(1,2)={'Partition Entropy'};
EV(1,3)={'Fakuyama & Sugeno'};
EV(1,4)={'Xie & Beni Index'};
EV(1,5)={'Rezaee et al'};
EV(1,6)={'Silhouette'};
EV(1,7)={'DaviesBouldin'};
EV(1,8)={'CalinskiHarabasz'};
EV(1,9)={'Rand Index'};
for ii=1:size(Ev1,2)
EV{2,ii}=num2str(Ev1(1,ii));
end
% if cri1==1
% figure(4);
% bar(eva1.ClusterSilhouettes{1,1})
% Sil=eva1.CriterionValues  ;
% ax = gca;
% ax.FontSize = 12;
% ax.LineWidth=1.5;
% end
for ii=1:i
    V(1,ii)={sprintf('Cluster %d',floor(ii))};
end
V(2:(size(V1,1)+1),:)=V1;
for i=1:size(V,1)
    for j=1:size(V,2)
        if isempty(V{i,j})
            V{i,j}='';
        end
    end
end
for i=1:size(EV,1)
    for j=1:size(EV,2)
        if isempty(EV{i,j})
            EV{i,j}='';
        end
    end
end