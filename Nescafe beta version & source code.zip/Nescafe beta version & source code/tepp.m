% global jk
global jj;

global params;
global Ra;
% params=params(kk2,:);
% Ra=Ra(kk2);
params=params(jj,:);
Ra=Ra(jj);
% p = smoothts(params);
% params=p;