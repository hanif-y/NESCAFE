%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% MATLAB Code for                                               %
%                                                               %
%  FCM CLuSTERING                                               %
%                                                               %
%                                                               %
%    Programmed By: H.yaghoobi                                  %
%                                                               %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function imp=CalculateTotalCosts(imp)

    global ICASettings;
    zeta=ICASettings.zeta;

    for i=1:numel(imp)
        
        cc=[imp(i).Colonies.Cost];
        
        imp(i).TotalCost=imp(i).Cost+zeta*mean(cc);
        
    end

end