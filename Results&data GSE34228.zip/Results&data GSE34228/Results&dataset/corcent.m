r1=[];
for i=1:3
    for j=1:8
        for k=1:3
            d=S{1,5}(i,:);
            t=S{1,j}(k,:);
            r=corrcoef(d,t);
            r1(1,k)=r(1,2);
        end
            r2(i,j)=find(r1(1,:)==max(r1(1,:)));
            r3(i,j)=max(r1(1,:));
           
    end
end
ss={};
k=0;
for i=1:3
    for j=r2(i,:)
        k=k+1;
        ss{1,i}(k,:)=S{1,k}(j,:);
    end
    k=0;
end

            