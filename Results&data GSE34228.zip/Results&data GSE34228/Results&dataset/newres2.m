
for i=1:size(Y,1)
    
    A(i,:)=strcmp(Ra,Y{i,1});
    if sum(A(i,:))>1
        cp=find(A(i,:)==1);
        A(i,cp(2:end))=0;
    end
end
B=sum(A);
B=B==1;
sum(B)
Dx=params(B,:);
subplot(3,2,2)
plot(Dx','LineWidth',2);
grid on;
    ax = gca;
    ax.FontSize = 20;
    ax.LineWidth=2;
