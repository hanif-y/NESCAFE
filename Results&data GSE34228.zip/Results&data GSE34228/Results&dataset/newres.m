[file1,path1] = uigetfile('*.csv','*.mat','Select One File');
gseData = importdata([path1,file1]);
X=gseData(2:10,1);
Y=gseData(2:10,2);
Z=gseData(2:end,3);
