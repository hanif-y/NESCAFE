subplot(2,2,1)
plot(S{1,5}(1,:)','LineWidth',2)
hold on;
plot(S{1,6}(3,:)','LineWidth',2)
plot(S{1,7}(2,:)','LineWidth',2)
plot(S{1,8}(1,:)','LineWidth',2)
legend({'C.C=1','C.C=0.8','C.C=0.88','C.C=0.8'},'FontSize',15)
legend('boxoff')
grid on;
    ax = gca;
    ax.FontSize = 20;
    ax.LineWidth=2;
subplot(2,2,2)
plot(S{1,5}(2,:)','LineWidth',2)
hold on;
plot(S{1,6}(2,:)','LineWidth',2)
plot(S{1,7}(1,:)','LineWidth',2)
plot(S{1,8}(3,:)','LineWidth',2)
legend({'C.C=1','C.C=0.83','C.C=0.59','C.C=0.87'},'FontSize',15)
legend('boxoff')
grid on;
    ax = gca;
    ax.FontSize = 20;
    ax.LineWidth=2;
subplot(2,2,3)
plot(S{1,5}(3,:)','LineWidth',2)
hold on;
plot(S{1,6}(1,:)','LineWidth',2)
plot(S{1,7}(3,:)','LineWidth',2)
plot(S{1,8}(2,:)','LineWidth',2)
% legend({'C.C=1','C.C=0.86','C.C=0.82','C.C=0.86'},'FontSize',15)
% legend('boxoff')


grid on;
    ax = gca;
    ax.FontSize = 20;
    ax.LineWidth=2;
    
    legend('PC9GR-None','PC9GR-Irs','PC9GR-EGF','PC9GR-Irs+EGF')